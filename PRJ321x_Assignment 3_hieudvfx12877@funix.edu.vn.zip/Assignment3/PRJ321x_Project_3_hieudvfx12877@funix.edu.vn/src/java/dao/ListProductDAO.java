/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import context.DBContext;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Product;

/**
 *
 * @author caheo
 */
public class ListProductDAO {

    //return the list of products by product name
    public List<Product> search(String chracters) throws Exception {
        List<Product> items = new ArrayList<>();
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            String sql = "select * from ShoppingDB.dbo.Products order by product_name";
                try (ResultSet rs = stm.executeQuery(sql)) {
                    while(rs.next()) {
                        int productID = rs.getInt(1);
                        String productName = rs.getString(2);
                        String productInfor = rs.getString(3);
                        float productPrice = rs.getFloat(4);
                        String productImageLink = rs.getString(5);
                        String productType = rs.getString(6);
                        String productBrand = rs.getString(7);
                        Product p = new Product(productID, productName, productInfor, productPrice, productImageLink, productType, productBrand);
                        items.add(p);
                    }  
                    rs.close();
                    stm.close();
                    conn.close();
                }
        }
        return items;
    }
    
    public Product getProduct(String character) throws Exception {
        Product p = new Product();
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            String sql = "select * from ShoppingDB.dbo.Products where product_id = "+character;
                try (ResultSet rs = stm.executeQuery(sql)) {
                    while(rs.next()) {
                        int productID = rs.getInt(1);
                        String productName = rs.getString(2);
                        String productInfor = rs.getString(3);
                        float productPrice = rs.getFloat(4);
                        String productImageLink = rs.getString(5);
                        String productType = rs.getString(6);
                        String productBrand = rs.getString(7);
                        p = new Product(productID, productName, productInfor, productPrice, productImageLink, productType, productBrand);
                    }  
                    rs.close();
                    stm.close();
                    conn.close();
                }
        }
        return p;
    }
    
    //dem so luong tat ca sp
    public int getTotalProduct(){
        String query = "select count(*) from ShoppingDB.dbo.Products";
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            try (ResultSet rs = stm.executeQuery(query)) {
                while(rs.next()) {
                    return rs.getInt(1);
                }   
            rs.close();
            stm.close();
            conn.close();
            }
        }catch(Exception e){}
        return 0;
    }
        //dem so luong tat ca sp
    public int getTotalProduct(String txtSearch){
        String query = "select count(*) from ShoppingDB.dbo.Products where product_name like '%"+txtSearch+"%'";
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            try (ResultSet rs = stm.executeQuery(query)) {
                while(rs.next()) {
                    return rs.getInt(1);
                }   
            rs.close();
            stm.close();
            conn.close();
            }
        }catch(Exception e){}
        return 0;
    }
    //
    public int firtsPage(){
        int a = getTotalProduct();
        if(a>6){
            return 5;
        } else{
            return a;
        }
    }
    //paging all product
    public List<Product> pagingProduct(int index) throws Exception{
        List<Product> list = new ArrayList<>();
        String query = "select * from ShoppingDB.dbo.Products order by product_name offset "+((index-1)*6)+" rows fetch next 6 rows only";
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            try (ResultSet rs = stm.executeQuery(query)) {
                while(rs.next()) {
                    int productID = rs.getInt(1);
                    String productName = rs.getString(2);
                    String productInfor = rs.getString(3);
                    float productPrice = rs.getFloat(4);
                    String productImageLink = rs.getString(5);
                    String productType = rs.getString(6);
                    String productBrand = rs.getString(7);
                    Product p = new Product(productID, productName, productInfor, productPrice, productImageLink, productType, productBrand);
                    list.add(p);
                }
                rs.close();
                stm.close();
                conn.close();
            }
        }
        return list;
    }
    //paging search product
    public List<Product> pagingProduct(int index, String txtSearch) throws Exception{
        List<Product> list = new ArrayList<>();
        String query = "select * from ShoppingDB.dbo.Products where product_name like '%"+txtSearch+"%' order by product_name offset "+((index-1)*6)+" rows fetch next 6 rows only";
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            try (ResultSet rs = stm.executeQuery(query)) {
                while(rs.next()) {
                    int productID = rs.getInt(1);
                    String productName = rs.getString(2);
                    String productInfor = rs.getString(3);
                    float productPrice = rs.getFloat(4);
                    String productImageLink = rs.getString(5);
                    String productType = rs.getString(6);
                    String productBrand = rs.getString(7);
                    Product p = new Product(productID, productName, productInfor, productPrice, productImageLink, productType, productBrand);
                    list.add(p);
                }
                rs.close();
                stm.close();
                conn.close();
            }
        }
        return list;
    }

}