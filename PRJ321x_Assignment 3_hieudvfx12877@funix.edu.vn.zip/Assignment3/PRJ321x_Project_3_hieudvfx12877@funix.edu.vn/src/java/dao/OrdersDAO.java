/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import context.DBContext;
import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import model.Cart;
import model.Orders;
import model.Product;

/**
 *
 * @author caheo
 */
public class OrdersDAO {
    //insert information of Order to data source, that including list of 
    //products in cart (c) and information of buyer in Order o
    
//Use SCOPE_IDENTITY() second insert into tblRoleOfStuff on a place of StaffId. Like:
//
//insert into tblStaff values
//(@name, @age, @address)
//
//insert into tblRoleOfStuff values
//(scope_identity(), @roleid)
    public void insertOrder(Orders o, Cart c) throws Exception {
        List<Product> items;
        LocalDate currentdate = LocalDate.now();
        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
            String sqla = " insert into ShoppingDB.dbo.Orders (user_mail, order_status, order_date, order_discount_code, order_address)"
                    + "values ('"+o.getUserMail()+"',"+o.getStatus()+",'"+currentdate+"','"+o.getDiscount()+"','"+o.getAddress()+"') ";
            String sqlb = "";
            int rs;
            double total = c.getAmount();
            items = c.getItems();
            int size = items.size();
            for(int j = 0; j < size; j++){
                Product i = items.get(j);
                if(j==0){
                    sqlb +=" insert into ShoppingDB.dbo.Orders_detail (order_id, product_id, amount_product, price_product)"
                        + "values (scope_identity(),"+i.getId()+","+total+","+i.getPrice()+") ";
                } else {
                    sqlb += ",(scope_identity(),"+i.getId()+","+total+","+i.getPrice()+") ";
                }
            }
//            for(Product i : items) {
//                sqlb +=" insert into ShoppingDB.dbo.Orders_detail (order_id, product_id, amount_product, price_product)"
//                        + "values (scope_identity(),"+i.getId()+","+total+","+i.getPrice()+") ";     
//            }
            String sqlc = sqla+ sqlb;
            rs = stm.executeUpdate(sqlc);
            stm.close();
            conn.close();
        }
    }
    
//    public void insertOrders() throws Exception {
//        List<Product> items;
//        LocalDate currentdate = LocalDate.now();
//        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {      
//
////            for(Product i : items) {
//                String sql2 = "insert into ShoppingDB.dbo.Orders_detail (order_id, product_id, amount_product, price_product)"
//                        + "values (0,2,0,0);";
//                int rs = stm.executeUpdate(sql2);
////            }
//            stm.close();
//            conn.close();
//        }
//    }
    //khong the co 2 primary key
//    public static void main(String [] args) throws Exception{
//        OrdersDAO dao = new OrdersDAO();
//        dao.insertOrders();
//    }
}
