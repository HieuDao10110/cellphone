/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Account;

/**
 *
 * @author caheo
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
	request.setCharacterEncoding("utf-8");// vietnamese
	try {
            //destroy session--
            //To make sure the session is properly maintained, 
            //you must call this method before the response is committed.
            //If the container is using cookies to maintain session integrity and is asked to create a new session when the response is committed,
            //an IllegalStateException is thrown.
            //request.getSession(true).invalidate();
            //make sure that email is valid
            String regexMail = "^[A-Za-z0-9+_.-]+@(.+)$";
            //^                 # start-of-string
            //(?=.*[0-9])       # a digit must occur at least once
            //(?=.*[a-z])       # a lower case letter must occur at least once
            //(?=.*[A-Z])       # an upper case letter must occur at least once
            //(?=.*[@#$%^&+=])  # a special character must occur at least once
            //(?=\S+$)          # no whitespace allowed in the entire string
            //.{8,}             # anything, at least eight places though
            //$                 # end-of-string
            String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
            //collect data from a login form
            String userID = request.getParameter("user");
            String password = request.getParameter("pass");
            String rem = request.getParameter("remember");
            Account acc = new Account();
            acc.setName(userID); acc.setPwd(password);
            //read information of account in web.xml
            String uid = getServletContext().getInitParameter("username");
            String pwd = getServletContext().getInitParameter("password");
            //create new session
            HttpSession session = request.getSession(true);
            if(!password.matches(regex)||!userID.matches(regexMail)) {
                session.setAttribute("error", "invalid syntax");
                response.sendRedirect("login.jsp");
            } else {
                if (userID != null && acc.getPwd().equals(pwd) && acc.getName().equalsIgnoreCase(uid)) {
                    //add user and pass to cookie
                    if(rem != null) {
                        //save cookie
                        Cookie userC = new Cookie("user",userID);
                        Cookie passC = new Cookie("password",password);
                        //set time alive of cookie
                        userC.setMaxAge(9000);
                        passC.setMaxAge(9000);
                        //add cookie to the browser
                        response.addCookie(userC);
                        response.addCookie(passC);
                    }
                    //set session
                    session.setAttribute("user", userID);
                    response.sendRedirect("admin/index.jsp");
                } else {
                    session.setAttribute("error", "wrong username or password");
                    response.sendRedirect("login.jsp");
                }
            }
	} catch (NullPointerException e) {
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            rd.forward(request, response);			
            response.getWriter().println(e);
	} catch (Exception ex) {
            response.getWriter().println(ex);
	}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        session.setAttribute("error", "");
        Cookie arr[] = request.getCookies();
        session.setAttribute("fillUser", "");
        session.setAttribute("fillPass", "");
        if(arr!=null) {
            for(Cookie c : arr) {
                if(c.getName().equals("user")) {
                    session.setAttribute("fillUser", c.getValue());
                }
                if(c.getName().equals("password")) {
                    session.setAttribute("fillPass", c.getValue());
                }
            }
        }
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
