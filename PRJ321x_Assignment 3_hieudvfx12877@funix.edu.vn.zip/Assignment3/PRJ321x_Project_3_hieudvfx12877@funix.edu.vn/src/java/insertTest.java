
import context.DBContext;
import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author caheo
 */
public class insertTest {
    public static void main(String [] args) throws Exception{
//        String a = "a";
//        int b = 2;
//       
//        try (Connection conn = new DBContext().getConnection(); Statement stm = conn.createStatement()) {
//            String sql = "SET IDENTITY_INSERT ShoppingDB.dbo.Orders ON insert into ShoppingDB.dbo.Orders (user_mail, order_id, order_status, order_date, order_discount_code, order_address)"
//                    + "values ('a',0,1,'2/2/2','b','c');";
//            int rs;
//            rs = stm.executeUpdate(sql);
//            stm.close();
//            conn.close();
//        }
//LocalDate currentdate = LocalDate.now();
//System.out.println(type(currentdate));
    }
}
